package com.reldyn.collection_framework___Arrays.stream;

import java.util.Arrays;
import java.util.stream.Stream;

public class Arrays_stream {
	public static void main(String[] args) {
		String s[]= {"Gaurav","Mahesh","Taple"};
		Stream<String> stream = Arrays.stream(s);
		stream.forEach(t->System.out.print(t+" "));
	}

}
