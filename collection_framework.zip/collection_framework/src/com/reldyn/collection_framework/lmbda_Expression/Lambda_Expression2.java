package com.reldyn.collection_framework.lmbda_Expression;

public interface Lambda_Expression2 {
	//void drawable();
	
	int inserting(int a,int b);

}
