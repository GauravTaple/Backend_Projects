package com.reldyn.collection_framework.predicate;

public class predicate2 implements inter {
	public static void main(String[] args) {
		inter.m1();
	}
	

}

interface inter{
	public static void m1()
	{
		System.out.println("interface");
	}
	
}
