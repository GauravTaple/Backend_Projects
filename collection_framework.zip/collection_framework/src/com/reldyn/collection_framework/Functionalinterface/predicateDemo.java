package com.reldyn.collection_framework.Functionalinterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class predicateDemo  {

//  For using this old method we need implements to predicate interface...
//	@Override
//	public boolean test(Integer t) {
//		if (t%2==0) {
//			return true;
//		}else
//		return false;
//	}

	public static void main(String[] args) {
		
//		-------------------------1st way-------------------------------------------------------
		
//		Predicate<Integer> pre=new predicateDemo();
//		System.out.println(pre.test(7));
		
		//-----------------------2nd way-------------------------------------------------------
		
		Predicate<Integer> pred=t->t%2==0;
		System.out.println(pred.test(5));
		
//		------------------example------------------
		List<Integer> l1=Arrays.asList(1,5,6,8,7,10,9);
		System.out.println(l1);
		l1.stream().filter(pred).forEach(y->System.out.println("print Even:"+y));
		
		
		
		
		
	}

}
