package com.reldyn.collection_framework.Functionalinterface;

import java.util.Arrays;
import java.util.List;

public class Supplier {

//	1st way---------------using this we need to implements supplier interface
//	@Override
//	public String get() {
//		return "This is get method called by using supplier";
//	} 
	
	public static void main(String[] args) {
//-------------------		1st way   ----------------------
//	java.util.function.Supplier<String> sup=new Supplier();
//		System.out.println(sup.get());
		
//-----------------          2nd Way   -----------------------
//		java.util.function.Supplier<String> suppl= ()->{return "This is called by using lambda expression";};
//		System.out.println(suppl.get());
//		
//		java.util.function.Supplier<Integer> suppl2=()->{return 20;};
//		System.out.println(suppl2.get());
//		
//-----------------          3rd way   ------------------------
		java.util.function.Supplier<String> suppli=()->"This is 3rd/latest way of writing";
		System.out.println(suppli.get());
		
		List<String> li=Arrays.asList("L","J","K");
		System.out.println(li.stream().findFirst().orElseGet(suppli));
		
		List<String> list=Arrays.asList();
		System.out.println(list.stream().findAny().orElseGet(()->"using lambda expression"));
		 
	}

}
