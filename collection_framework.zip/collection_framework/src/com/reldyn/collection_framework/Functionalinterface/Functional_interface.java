package com.reldyn.collection_framework.Functionalinterface;
@FunctionalInterface
public interface Functional_interface {
//	public void Say();
	
	
//	public void say(int a,int b);
	
	public void squqreit(int n);

}
