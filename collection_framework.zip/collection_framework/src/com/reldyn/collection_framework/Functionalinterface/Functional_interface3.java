package com.reldyn.collection_framework.Functionalinterface;

public class Functional_interface3 {
	
	public static void main(String[] args) {
//		Functional_interface f=()->System.out.println("Functional interface");
//		f.Say();
		
//		Functional_interface f1=(a,b)->System.out.println("Sum is "+(a+b));
//		f1.say(10, 20);
		

		
	
		
	}

}
