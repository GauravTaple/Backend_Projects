package com.reldyn.collection_framework.Functionalinterface;

public class Functional_interface1 implements Functional_interface {

//	@Override
//	public void Say() {
//		System.out.println("Override say method");
//		
//	}
	
	@Override
	public void squqreit(int n) {
		System.out.println(n+20);
	}
	
	public static void main(String[] args) {
		Functional_interface1 b=new Functional_interface1();
		//b.Say();
		
		b.squqreit(30);
	}

	
	

}
