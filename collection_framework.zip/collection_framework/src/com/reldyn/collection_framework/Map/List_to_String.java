package com.reldyn.collection_framework.Map;

import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class List_to_String {
	public static void main(String[] args) {
		List<Character> list=Arrays.asList('G','A','U','R','A','V');
		System.out.println("List:-"+list);
		
		//list to string conversion without using stream
		StringBuilder builder=new StringBuilder();
		for (Character character : list) {
			builder.append(character);
		}
		System.out.println("String:-"+builder);
		
		
		//list to String conversion using stream
		String collect = list.stream().map(String::valueOf).collect(Collectors.joining());
		System.out.println("String:-"+collect);
		
	}
}
