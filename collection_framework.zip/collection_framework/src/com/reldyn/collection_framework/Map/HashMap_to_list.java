package com.reldyn.collection_framework.Map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

public class HashMap_to_list {
	public static void main(String[] args) {
		Map<Integer, String> m = new HashMap<>();
		m.put(1, "john");
		m.put(2, "cena");
		System.out.println(m);
		System.out.println("-----------------------------------------------------------");
		
		
		//map to list conversion and get only the key
		List<Integer> collect = m.keySet().stream().collect(Collectors.toList());
		collect.stream().forEach(t->System.out.println(t));
		System.out.println("************************************************************");
		
		
		//map to list conversion and get only values
		List<String> collect2 = m.values().stream().collect(Collectors.toList());
		//iterate the list using forEach
		collect2.forEach(s->System.out.println(s));
		System.out.println(collect2);
		System.out.println("-------------------------------------------------------------");
		
		
		//get both the keys and values in a list
		List<Entry<Integer,String>> collect3 = m.entrySet().stream().collect(Collectors.toList());
		System.out.println(collect3);
		
	
		
		


	
	}

}