package com.reldyn.collection_framework.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class list_to_map {
	
	public static void main(String[] args) {
		List<StudentEntity> l=new ArrayList<>();
		l.add(new StudentEntity(1, "Gaurav", 22));
		l.add(new StudentEntity(2,"Shubham",23));
		l.add(new StudentEntity(3, "Sarthak", 24));
		System.out.println(l);
		
System.out.println("------------------------------------------------");
//List to map conversion without using stream/java 1.8 features
		Map<String, Integer> map=new HashMap<>();
		for(StudentEntity s:l)
		{
			map.put(s.getName(), s.getAge());
		}
		System.out.println(map);
		
		
System.out.println("***************************************************");
//List to map conversion and fetch the name and age using stream 
		Map<String,Integer> collect = l.stream().collect(Collectors.toMap(StudentEntity::getName, StudentEntity::getAge));
		System.out.println(collect);
		
		
System.out.println("--------------------------------------------------");
//list to map only fetch the name using stream 
      //-----------------1st way------------------
		List<String> list = l.stream().map(t->t.getName()).toList();
		list.stream().forEach(t->System.out.println(t));
		
	  //-----------------2nd way-----map.put(10, ne)-------------
		System.out.println("*---------*---------*----------*----------*");
		List<String> list2 = l.stream().map(StudentEntity::getName).toList();
		list2.stream().forEach(t->System.out.println(t));
		
	

	}

}
