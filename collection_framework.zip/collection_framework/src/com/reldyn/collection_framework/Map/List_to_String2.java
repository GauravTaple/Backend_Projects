package com.reldyn.collection_framework.Map;

import java.util.List;
import java.util.stream.Collectors;

//string to list conversion using stream
public class List_to_String2 {
	public static void main(String[] args) {
		String str="Gaurav";
		List<Character> chars=stringToChar(str);
		System.out.println(chars);
	}
	
	public static List<Character> stringToChar(String str)
	{
		List<Character> chars = str.chars().mapToObj(e->(char)e).collect(Collectors.toList());
		return chars;
		
	}

}
