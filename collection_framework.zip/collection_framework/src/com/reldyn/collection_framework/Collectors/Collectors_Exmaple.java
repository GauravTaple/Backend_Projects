package com.reldyn.collection_framework.Collectors;

public class Collectors_Exmaple {
	public static void main(String[] args) {
		
	}

}
