package com.reldyn.collection_framework.map_Flatmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Map_Flatmap_main {
	public static void main(String[] args) {
		List<Map_flatmap> m=new ArrayList<>();
		m.add(new Map_flatmap("IIM", Arrays.asList("Pune","Hyderabad","mumbai")));
		m.add(new Map_flatmap("IIT", Arrays.asList("Thane","Lucknow","Shirur")));
		m.add(new Map_flatmap("IIB", Arrays.asList("Banglore","Karnataka","Karjat")));
		System.out.println(m);
		
        //Java 8 Map() : Get names of all institutes
		List<String> collect = m.stream().map(Map_flatmap::getName).collect(Collectors.toList());
		System.out.println(collect);
		
		//Java 8 FlatMap() : Get unique locations of all institutes
		Set<String> collect2 = m.stream().flatMap(t->t.getLocations().stream()).collect(Collectors.toSet());
		System.out.println(collect2);
		
	}

}
