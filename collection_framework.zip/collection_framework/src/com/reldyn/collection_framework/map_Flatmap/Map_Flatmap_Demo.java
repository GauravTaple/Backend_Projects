package com.reldyn.collection_framework.map_Flatmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Map_Flatmap_Demo {
	public static void main(String[] args) {
		
		//program for map....................
		List<String> s=new ArrayList<>();
		s.add("Apple");
		s.add("Banana");
		s.add("Grapes");
		System.out.println(s);
		List<Integer> collect = s.stream().map(j->j.length()).collect(Collectors.toList());
		System.out.println("String length is:-"+collect);
		
		
		//program for flatmap.................
		List<List<String>> s1=new ArrayList<>();
		s1.add(Arrays.asList("eat","junk"));
		s1.add(Arrays.asList("man","swim"));
		s1.add(Arrays.asList("hat","pull"));
		System.out.println(s1);
		List<String> collect2 = s1.stream().flatMap(t->t.stream()).collect(Collectors.toList());
		System.out.println(collect2);
	}

}
