package com.reldyn.collection_framework.map_Flatmap;

import java.util.List;

public class Map_flatmap {
	String name;
	List<String> locations;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getLocations() {
		return locations;
	}
	@Override
	public String toString() {
		return "[name=" + name + ", locations=" + locations + "]";
	}
	public void setLocations(List<String> locations) {
		this.locations = locations;
	}
	public Map_flatmap(String name, List<String> locations) {
		super();
		this.name = name;
		this.locations = locations;
	}
	
	

}
