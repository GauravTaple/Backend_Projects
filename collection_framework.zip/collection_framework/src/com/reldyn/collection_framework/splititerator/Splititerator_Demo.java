package com.reldyn.collection_framework.splititerator;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;
import java.util.stream.Stream;

public class Splititerator_Demo {
	public static void main(String[] args) {
	List<Integer> list=Arrays.asList(2,3,4,5,9);
	System.out.println(list);

	//estimateSize() method
	long estimateSize = list.stream().spliterator().estimateSize();
	System.out.println("Estimate size:-"+estimateSize);
	System.out.println("--------------------------------------------------------");
	
	//tryAdvance() method
	Spliterator<Integer> s=list.spliterator();
	boolean tryAdvance = s.tryAdvance(k->System.out.println(k));
	boolean tryAdvance2 = s.tryAdvance(System.out::println);
	boolean tryAdvance3 = s.tryAdvance(System.out::println);
	
	System.out.println("--------------------------------------------------------");
	
	//forEachRemaining() method
	list.stream().spliterator().forEachRemaining(t->System.out.println(t));
		
	System.out.println("----------------------------------------------------------");
	
	Spliterator<Integer> s1=list.spliterator();
	Spliterator<Integer> s2=s1.trySplit();
	s1.forEachRemaining(j->System.out.println(j));
	System.out.println("after splitting with s2 variable:");
	s2.forEachRemaining(j->System.out.println(j));

	}

}
