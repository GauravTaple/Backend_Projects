package com.reldyn.collection_framework.Time_Date;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class Java_Date {
	public static void main(String[] args) {
		System.out.println(System.currentTimeMillis()/1000/3600/12/365);
		System.out.println("---------------------------------------------------");
		
		Date date1=new Date();
		System.out.println(date1);
		
		LocalDate date=LocalDate.now();
		System.out.println(date);
		System.out.println(date.getDayOfMonth());
		System.out.println(date.getDayOfYear());
		System.out.println("-----------------------------------------------------");
		
		
		LocalTime time=LocalTime.now();
		System.out.println(time);
		System.out.println(time.getHour());
		System.out.println("------------------");
		
		
	}

}
