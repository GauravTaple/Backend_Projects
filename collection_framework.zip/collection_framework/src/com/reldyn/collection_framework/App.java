package com.reldyn.collection_framework;

public class App {

}
