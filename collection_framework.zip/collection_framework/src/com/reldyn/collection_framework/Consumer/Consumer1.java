package com.reldyn.collection_framework.Consumer;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Consumer1 {
	public static void main(String[] args) {
		Consumer<Integer> consumer=t->System.out.println("Printing:"+t);
		consumer.accept(10); 
		System.out.println("----------------------"); 
		
		List<Integer> l=Arrays.asList(1,2,3,4,5);
		l.stream().forEach(t->System.out.println(t));
		
		
	}
 
}
     