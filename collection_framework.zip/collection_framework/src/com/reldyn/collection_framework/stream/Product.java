package com.reldyn.collection_framework.stream;

public class Product {
	int id;
	String name;
	long price;
	
	Product(int a,String b,long c)
	{
		this.id=a;
		this.name=b;
		this.price=c;
	}

}
