package com.reldyn.collection_framework.Enum;

import java.util.EnumSet;

enum gfg {code,learn,without,fear};
public class Enum_exmaple {
	
	enum code{java,python,c,ruby,kotlin};
	
	enum lang{marathi,english,hindi};
	
	
	public static void main(String[] args) {
	EnumSet<gfg> enums= EnumSet.allOf(gfg.class);
	System.out.println(enums);
	
	EnumSet<code> codes=EnumSet.allOf(code.class);
	System.out.println(codes);
	
	EnumSet<lang> langs=EnumSet.noneOf(lang.class);
	System.out.println(langs);
	
	}
	

}
