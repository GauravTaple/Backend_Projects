package com.reldyn.collection_framework.Enum;

public class Enum3 {
	public static void main(String[] args) {
		TrafficSignal[] ts = TrafficSignal.values();

		for (TrafficSignal Signal : ts) {
			System.out.println("Name:" + Signal.name() + "   Action:" + Signal.getAction());

		}
	}

}

enum TrafficSignal {
	RED("Stop"), GREEN("GO"), ORANGE("WAIT");

	private String action;

	public String getAction() {
		return this.action;
	}

	private TrafficSignal(String action) {
		this.action = action;
	}

}
