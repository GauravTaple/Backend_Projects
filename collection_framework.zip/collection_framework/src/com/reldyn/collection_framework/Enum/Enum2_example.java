package com.reldyn.collection_framework.Enum;

//Declared the enum in outside the class
enum month {
	jan, feb, march;
}

public class Enum2_example {
//Declared the enum in inside the class
	enum car {
		yamaha, suzuki, pulsar;
	}

	public static void main(String[] args) {
		// With the help of enum we can access one perticular constants.
		month m = month.feb;
		System.out.println(m);

		car c = car.suzuki;
		System.out.println(c);

	}
}
