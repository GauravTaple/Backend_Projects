package com.reldyn.collection_framework.methodReferences;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

//System.out.println("123".compareTo("321")); 
//
public class Method_reference_main {
	public static int CompareByName(Entity a, Entity b) {
		return a.getName().compareTo(b.getName());
		
	}
	
	public static int CompareByAge(Entity a, Entity b) {
		return a.getAge().compareTo(b.getAge());
	}
	
	public int CompareByName1(Entity a,Entity b) {
		return a.getName().compareTo(b.getName());
		
	}
	
	public int CompareByAge1(Entity a,Entity b) {
		return a.getAge().compareTo(b.getAge());
		
	}
	
	public static void main(String[] args) {
		List<Entity> s=new LinkedList();
		s.add(new Entity(1, "sam", 20));
		s.add(new Entity(2, "gaurav",22));
		s.add(new Entity(3, "jack", 25));
		System.out.println(s);
		System.out.println("--------------------");
		
// Using static method reference--------------------------------------------------------------------------
		//sort array by name
		Collections.sort(s,Method_reference_main::CompareByName);
		
		//display message by using stream
		System.out.println("Sort by name:-");
		s.stream().map(j->j.getName()).forEach(System.out::println);
		
		System.out.println("---------------------");
		
		//using static method reference
		//sort by age
		Collections.sort(s,Method_reference_main::CompareByAge);
		
		//display message by using stream
		System.out.println("Sort by age:-");
		s.stream().map(l->l.getName()).forEach(System.out::println);
		System.out.println("----------------------------------");
		
//using Reference to an instance method of a particular object--------------------------------------------
		Method_reference_main mr=new Method_reference_main();
		Collections.sort(s,mr::CompareByName1);
		
		//display message using stream
		System.out.println("Sort by name:");
		s.stream().map(t->t.getName()).forEach(System.out::println);
		
		System.out.println("Sort by age:");
		Collections.sort(s,mr::CompareByAge1);
		s.stream().map(k->k.getName()).forEach(System.out::println);
		
	}

}
