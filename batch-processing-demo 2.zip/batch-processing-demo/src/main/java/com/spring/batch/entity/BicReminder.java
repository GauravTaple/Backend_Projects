package com.spring.batch.entity;

import lombok.*;
import org.springframework.batch.item.ResourceAware;
import org.springframework.core.io.Resource;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BicReminder implements ResourceAware {

    private String no;
    private String type;
    private String date;
    private String cardBic;
    private String acNo;
    private String title;
    private String name;
    private String namePsw;
    private String amount;
    private String add1;
    private String add2;
    private String add3;
    private String add4;
    private String add5;
    private String poskod;
    private String city;
    private String cycle;
    private String code;
    private String email;
    private String icNo;
    private Resource resource;

}
