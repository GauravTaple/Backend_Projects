package com.spring.batch.entity;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.w3c.dom.Text;

import java.time.LocalDateTime;

@Entity
@Data
@Builder
@Table(name = "record_log")
public class RecordLog {

    @Id
    @GeneratedValue(generator = "id-generator")
    @GenericGenerator(name = "id-generator")
    @Column(name = "id" , length = 64, nullable = false)
    private int Id;

    @Column(name = "job_execution_id" , length = 500, nullable = false)
    private Long jobExecutionId;

    @Column(name = "generated_file_name" , length = 500, nullable = false)
    private String generatedFileName;

    @Column(name = "source_file_name" , length = 500)
    private String sourceFileName;

    @Column(name = "password" , length = 16, nullable = false)
    private String password;

    @Column(name = "email" , columnDefinition = "text")
    private String email;

    @Column(name = "generated_At" , length = 64, nullable = false)
    private LocalDateTime generatedAt;


}



