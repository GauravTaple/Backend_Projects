package com.spring.batch.config;

import com.spring.batch.entity.BicReminder;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.springframework.batch.item.*;

import java.io.FileOutputStream;
import java.io.IOException;


@Slf4j
public class ExcelItemWriter implements ItemWriter<BicReminder>{

    private final String filePath;
    private  int sheetName;

    private final Workbook workbook;


    public ExcelItemWriter(String filePath, int sheetName, Workbook workbook){
        this.filePath = filePath;
        this.sheetName = sheetName;
        this.workbook = workbook;
    }

    @Override
    public void write(Chunk<? extends BicReminder> chunk){
        try {
            Sheet sheet = workbook.createSheet("CL0" + (sheetName + 1));

            Row header = sheet.createRow(0);
            header.setHeightInPoints(25);

            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.TAN.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderTop(BorderStyle.THIN);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);
            headerStyle.setWrapText(true);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);

            Font headerFont = (workbook).createFont();
            headerFont.setFontName("Arial");
            headerFont.setFontHeightInPoints((short) 10);
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            Cell headerCell = header.createCell(0);
            headerCell.setCellValue("NO");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(1);
            headerCell.setCellValue("TYPE");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(2);
            headerCell.setCellValue("DATE");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(3);
            headerCell.setCellValue("CARD BIC");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(4);
            headerCell.setCellValue("A/C NO");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(5);
            headerCell.setCellValue("NAME");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(6);
            headerCell.setCellValue("AMOUNT");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(7);
            headerCell.setCellValue("ADD 1");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(8);
            headerCell.setCellValue("ADD 2");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(9);
            headerCell.setCellValue("ADD 3");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(10);
            headerCell.setCellValue("ADD 4");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(11);
            headerCell.setCellValue("ADD 5");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(12);
            headerCell.setCellValue("POSKOD");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(13);
            headerCell.setCellValue("CITY");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(14);
            headerCell.setCellValue("CYCLE");
            headerCell.setCellStyle(headerStyle);

            headerCell = header.createCell(15);
            headerCell.setCellValue("CODE");
            headerCell.setCellStyle(headerStyle);

            CellStyle rowStyle = workbook.createCellStyle();
            rowStyle.setAlignment(HorizontalAlignment.CENTER);

            Font rowFont = (workbook).createFont();
            rowFont.setFontName("Arial");
            rowFont.setFontHeightInPoints((short) 11);
            rowStyle.setFont(rowFont);

            int rowIndex = 0;
            for (BicReminder bicReminder : chunk) {
                Row row = sheet.createRow(++rowIndex);

                Cell rowCell = row.createCell(0);
                rowCell.setCellValue(rowIndex);
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(1);
                rowCell.setCellValue(bicReminder.getType());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(2);
                rowCell.setCellValue(bicReminder.getDate());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(3);
                rowCell.setCellValue(bicReminder.getCardBic());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(4);
                rowCell.setCellValue(bicReminder.getAcNo());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(5);
                rowCell.setCellValue(bicReminder.getName());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(6);
                rowCell.setCellValue(bicReminder.getAmount());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(7);
                rowCell.setCellValue(bicReminder.getAdd1());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(8);
                rowCell.setCellValue(bicReminder.getAdd2());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(9);
                rowCell.setCellValue(bicReminder.getAdd3());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(10);
                rowCell.setCellValue(bicReminder.getAdd4());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(11);
                rowCell.setCellValue(bicReminder.getAdd5());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(12);
                rowCell.setCellValue(bicReminder.getPoskod());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(13);
                rowCell.setCellValue(bicReminder.getCity());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(14);
                rowCell.setCellValue(bicReminder.getCycle());
                rowCell.setCellStyle(rowStyle);

                rowCell = row.createCell(15);
                rowCell.setCellValue(bicReminder.getCode());
                rowCell.setCellStyle(rowStyle);
            }
            FileOutputStream outputStream = new FileOutputStream(filePath);
            workbook.write(outputStream);
            sheetName++;
        } catch (IOException e) {
            log.error("Error while writing xlsx file {}",e.getMessage());
        }
    }
}
