package com.spring.batch.config;

import com.spring.batch.entity.BicReminder;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.batch.item.ItemProcessor;

public class EmailFilterItemProcessor implements ItemProcessor<BicReminder, BicReminder> {
    @Override
    public BicReminder process(BicReminder bicReminder) throws Exception {

        if (ObjectUtils.isEmpty(bicReminder.getEmail())){
            return bicReminder;
        }
        return null;
    }
}
